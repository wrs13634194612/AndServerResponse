#ifndef __SOCKET_RPC_DEF_H__
#define	__SOCKET_RPC_DEF_H__

#if defined(__cplusplus)
	extern "C"
	{
#endif

typedef enum 
{
   SYSTEM_AGENT_RPC_SERVER_PORT = 2000 ,
   COMMON_AGENT_RPC_SERVER_PORT ,
   HIMPP_AGENT_RPC_SERVER_PORT ,
   RTPSERVER_AGENT_RPC_SERVER_PORT,
   SIP_AGENT_RPC_SERVER_PORT,
}RPC_SERVER_PORT_DEF;


typedef struct _tagSocketRpcMsg
{
	int cmd ;
	int DataLen;
	char data[0];
}SocketRpcMsg;

#define MAX_SOCKET_RPC_DATA_LEN (256)

#ifndef IPV4_ADDR_LEN
#define IPV4_ADDR_LEN 16
#endif

#define LO_IP_ADDR "127.0.0.1"
#define NULL_IP_ADDR "0.0.0.0"

int SocketRpcCreateServer(char* ipaddr,int bindport,int protocol);
int SocketRpcConnect(char* ipaddr,int port, int protocol);
int SocketRpcMsgSend(int SocketFd,int cmd,void* data, int data_len);
int SocketRpcMsgSendto(int SocketFd,char * RemoteAddr,int RemotePort,SocketRpcMsg* msg);
int SocketRpcRecv(int fd,char* DataBuf, int bufsize);
int SocketRpcRecvWait(int fd,char* DataBuf, int bufsize,int timeout_ms);
int SocketRpcRecvFrom(int fd,char* DataBuf, int bufsize,char* RemoteAddr, int* RemotePort);
int SocketRpcRecvFromWait(int fd,char* DataBuf, int bufsize,char* RemoteAddr, int* RemotePort,int timeout);
int SocketRpcMsgRcvWait(int fd,int cmdid,char* pdata, int bytes,int timeout_ms);
int SocketRpcSendToClient(int fd,char* RemoteAddr,unsigned int RemotePort,int cmd,void *pdata,int len);


int LocalClientRpcConnect(int port);
int SocketClientRpcSend(int fd,int CmdId,void *pdata,int len);
int SocketClientRpcRcv(int fd,int cmdid,char* pdata, int bytes);
int SocketClientRcvAck(int fd,int cmdid);


#if defined(__cplusplus)
	} // extern "C"
#endif


#endif

