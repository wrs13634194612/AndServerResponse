#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h> 
#include <sys/stat.h>  
#include <unistd.h>
#include "SocketUtil.h"
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

//#include"printf.h"
//#include"commonTool.h"

int CreateSocket(char* bindIP, int bindPort, int protocol)
{
	int SocketFD;
	struct sockaddr_in addr;

	SocketFD = socket(AF_INET, protocol, 0); //SOCK_DGRAM SOCK_STREAM
	if(SocketFD <= 0)
	{
		
		printf("Create Socket Failed:%m\n");
		return SocketFD;
	}

	if(NULL == bindIP && 0 == bindPort)
	{
		return SocketFD;
	}

	addr.sin_family = AF_INET;
	if(NULL != bindIP)
	{
		if(strlen(bindIP) == 0)
		{
			addr.sin_addr.s_addr = INADDR_ANY;
		}
		else
		{
			addr.sin_addr.s_addr = inet_addr(bindIP);
		}
	}
	else
	{
		addr.sin_addr.s_addr = INADDR_ANY;
	}

	if(0 != bindPort)
	{
		addr.sin_port = htons(bindPort);
	}
	else
	{
		addr.sin_port = 0;
	}
	if(bind(SocketFD, (struct sockaddr*)&addr, sizeof(addr)) == -1) 
	{
		
		printf("bind %s:%d failed, close socket!: %m\n", bindIP, bindPort);
		close(SocketFD);
		return -1;
	}
	return SocketFD;
}

void DestroySocket(int SocketFD)
{
	if(SocketFD > 0)
	{
		close(SocketFD);
	}
}

int ListenSocket(int SocketFD)
{
	return listen(SocketFD, 16);
}


int SocketCreateServer(char* ipaddr,int bindport,int protocol)
{
	int SocketFD = CreateSocket(ipaddr,bindport, protocol);
	if(SocketFD <= 0)
	{
		printf("Create SocketServer %d failed!",bindport);
		return -1;
	}
	
	if(SOCK_STREAM == protocol)
	{
		int ret = ListenSocket(SocketFD);
		if(ret < 0)
		{
			printf("SocketCreateServer Listen Failed!\n");
			close(SocketFD);
			return -2;
		}
	}
	
	return SocketFD;
}


int SocketDataSend(int SocketFD, void* data, int len)
{
	int ret;
	
	if( NULL == data ||
		len <= 0)
	{
		return -1;
	}
	if(SocketFD <= 0 )
	{
		return -2;
	}
	
	int sended = 0;
	int less = len;
	uint32_t time_out = time(NULL)+15;
	while((uint32_t)time(NULL)<time_out)
	{
		ret = send(SocketFD, data + sended, less, 0);
		if(ret <= 0)
		{
			if(errno==EINTR)
			{
				printf("send printf: %m\n");
				continue ;
			}
			else if(errno==EAGAIN)
			{
				
				printf("send printf: %m\n");
				sleep(1);
				continue ;
			}
			else
			{
			
				printf("send socket fd=%d data failed %d\n",SocketFD,ret);
				return ret;
			}
			
		}
		sended += ret;
		less = len - sended;
		if(less <= 0)
		{
			break;
		}
		printf("SocketDataSend less=%d\r\n",less);
	}
	return sended;
}

int SocketDataRecv(int SocketFD, void* dst, int dst_len)
{
	int ret;
	
	if(SocketFD <= 0 ||
		NULL == dst ||
		dst_len <= 0)
	{
		printf("SocketDataRecv printf\r\n");
		return -1;
	}

	ret = recv(SocketFD, dst, dst_len, 0);
	if(ret<0)
		{
		  printf("recv  printf :%m");
		}
	return ret;
}


int SocketDataSendTo(int SocketFD, void* data, int len,
							char* RemoteAddr, int RemotePort)
{
	struct sockaddr_in addr;
	int ret;

	if(SocketFD <= 0 || 
		NULL == data ||
		len <= 0 ||
		NULL == RemoteAddr ||
		RemotePort <= 0)
	{
		//printf_("failed socket = %d data = %p, len = %d, addr = %s:%d\n",
		//	SocketFD, data, len, RemoteAddr, RemotePort);
		return -1;
	}
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = inet_addr(RemoteAddr);
	addr.sin_port = htons(RemotePort);

	int sended = 0;
	int less = len;
	uint32_t time_out = time(NULL)+15;
	while((uint32_t)time(NULL)<time_out)
	{
		ret = sendto(SocketFD, data + sended, less, 0, (struct sockaddr*)&addr, sizeof(addr));
		if(ret <= 0)
		{
			if(errno==EINTR)
			{
				printf("sendto printf:%m\n");
				continue ;
			}
			else if(errno==EAGAIN)
			{
				printf("sendto printf:%m\n");
				sleep(1);
				continue ;
			}
			else
			{
				
				printf("send socket data failed printf:%m\n");
				break;
			}
			
		}
		sended += ret;
		less = len - sended;
		if(less <= 0)
		{
			break;
		}
		printf("SocketDataSend less=%d\r\n",less);
	}
	return sended;
}

int SocketDataRecvFrom(int SocketFD, void* dst, int dst_len,
							char* RemoteAddr, int* RemotePort)
{
	int ret;
	struct sockaddr_in addr;
	unsigned int addrlen;
	
	if(SocketFD < 0 ||
		NULL == dst ||
		dst_len <= 0 ||
		NULL == RemoteAddr ||
		NULL == RemotePort)
	{
		return -1;
	}
	addrlen = sizeof(addr);
	ret = recvfrom(SocketFD, dst, dst_len, 0, (struct sockaddr*)&addr, &addrlen);
	if(ret <= 0)
	{
		printf("%s(%d):%m\n",__FILE__,__LINE__);
		return ret;
	}
	strcpy(RemoteAddr, (char*)inet_ntoa(addr.sin_addr));
	*RemotePort = htons(addr.sin_port);
	return ret;
}

int SocketConnect(int iSocketFD ,char* pszCenterAddr, unsigned short  usPort)
{
	struct sockaddr_in servaddr;
	int iResult;

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(usPort);
	servaddr.sin_addr.s_addr = inet_addr(pszCenterAddr);
	iResult = connect(iSocketFD, (struct sockaddr *)&servaddr, sizeof(servaddr));
	if(iResult < 0)
	{
		printf("connect printf %m \r\n");
		return -1;
	}
	else
	{
		return iResult;
	}
}

#if 1
#define FCNTL_BLOCK
int ConnectToCenterWait(char* pszCenterAddr, unsigned short  usPort,int protocol,int timeout)
{
	int iSocketFD;
	int iResult;
	if(NULL == pszCenterAddr)
	{
		return -1;
	}

	iSocketFD = CreateSocket(NULL,0, protocol);
	if(iSocketFD<0)
		return -1;
#ifdef FCNTL_BLOCK
   int  flags=fcntl(iSocketFD,F_GETFL,0);
	fcntl(iSocketFD,F_SETFL,flags|O_NONBLOCK);
#else
	unsigned long ul = 1;
	ioctl(iSocketFD,FIONBIO,&ul);//����Ϊ������
 
#endif
	iResult = SocketConnect(iSocketFD,pszCenterAddr,usPort);
	if(iResult < 0)
	{
		if(errno!=EINPROGRESS)
		{
			close(iSocketFD);
			return -1;	
		}
		
		fd_set TotalFDSet;
		struct timeval tv;
		
		tv.tv_sec=timeout;
		tv.tv_usec=0;
		FD_ZERO(&TotalFDSet);
		FD_SET(iSocketFD, &TotalFDSet);
		if(select(iSocketFD+1,NULL,&TotalFDSet,NULL,&tv)>0)
		{
			int err = -1;
			int len = sizeof(int);
			getsockopt(iSocketFD,SOL_SOCKET,SO_ERROR,&err,(socklen_t *)&len);
			if(err!=0)
			{
				close(iSocketFD);
				return -1;
			}
		}
		else
		{
			close(iSocketFD);
			return -1;
		}
	}
	#ifdef FCNTL_BLOCK
	fcntl(iSocketFD,F_SETFL,flags);
	#else
	ul = 0;
	ioctl(iSocketFD,FIONBIO,&ul);//����Ϊ����
	#endif
	return iSocketFD;
}

int ConnectToCenter(char* pszCenterAddr, unsigned short  usPort,int protocol)
{
	return ConnectToCenterWait(pszCenterAddr,usPort,protocol,15);
}

#else
int ConnectToCenter(char* pszCenterAddr, unsigned short  usPort,int protocol)
{
	int iSocketFD;
	int iResult;
	if(NULL == pszCenterAddr)
	{
		return -1;
	}

	iSocketFD = CreateSocket(NULL,0, protocol);
	if(iSocketFD<0)
		return -1;

	iResult = SocketConnect(iSocketFD,pszCenterAddr,usPort);
	if(iResult < 0)
	{
		//printf("ConnectToCenter 3\r\n");
		close(iSocketFD);
		return -1;
	}
	
	return iSocketFD;
	
}
#endif

