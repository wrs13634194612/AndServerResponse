#ifndef __SOCKET_UTIL_DEF_H__
#define __SOCKET_UTIL_DEF_H__

#if defined(__cplusplus)
	extern "C"
	{
#endif

#define IPV4_ADDR_LEN 16
#define NET_PROTOCOL_TYPE_TCP 1
#define NET_PROTOCOL_TYPE_UDP 2
#define NET_BUFFER_MAX (1024*8)
#define MAX_MTU_LEN (1400)


int CreateSocket(char* bindIP, int bindPort, int protocol);
void DestroySocket(int SocketFD);
int ListenSocket(int SocketFD);


int SocketDataSend(int SocketFD, void* data, int len);
int SocketDataRecv(int SocketFD, void* dst, int dst_len);
int SocketDataSendTo(int SocketFD, void* data, int len,
							char* RemoteAddr, int RemotePort);
int SocketDataRecvFrom(int SocketFD, void* dst, int dst_len,
							char* RemoteAddr, int* RemotePort);
int ConnectToCenter(char* pszCenterAddr, unsigned short  usPort,int protocol);

int SocketCreateServer(char* ipaddr,int bindport,int protocol);
int SocketConnect(int iSocketFD ,char* pszCenterAddr, unsigned short  usPort);
int ConnectToCenterWait(char* pszCenterAddr, unsigned short  usPort,int protocol,int timeout);

#if defined(__cplusplus)
	} // extern "C"
#endif


#endif

