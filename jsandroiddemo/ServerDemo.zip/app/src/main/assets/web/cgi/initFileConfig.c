#include<stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include"initFileConfig.h"
//#include"IntercomSys.h"
#include <unistd.h>
//#include"Debug.h"
//#include"commonTool.h"
//#include"hiMppControl.h"
#define ETH0_CFG "/etc/network.d/interface.eth0"
typedef struct FileInitCfg_t
{
	int keycnt;
	char cfgPath[128];
	KeyVal kvlist[MAX_LEN];
}FileInitCfg;
FileInitCfg gFileInitCfg={0};
int praseKeyVal(char *keyvalstr,FileInitCfg *cfg)
{
	int ret=0;
	char key[32],val[64];
	memset(key,0,sizeof(key));
	memset(val,0,sizeof(val));
	ret=sscanf(keyvalstr,"%[^ ] = %[^\n]\n",key,val);
	if(ret!=2)
	{
		printf("ret(%d)  , str[%s]\n",ret,keyvalstr);
		return 0;
	}
	//Trim(key);
	//Trim(val);
	//printf("<p>key[%s]=val[%s] <p>\n",key,val);
	strcpy(cfg->kvlist[cfg->keycnt].keystr,key);
	strcpy(cfg->kvlist[cfg->keycnt].valstr,val);
	cfg->keycnt++;
	return ret;
}
int addCfgkey(FileInitCfg *cfg,char *key,char *val)
{
    strcpy(cfg->kvlist[cfg->keycnt].keystr,key);
	strcpy(cfg->kvlist[cfg->keycnt].valstr,val);
	cfg->keycnt++;
	return 0;
}
int delCfgkey(FileInitCfg *cfg,char *keystr)
{
	int i;
   for(i=0;i<cfg->keycnt;i++)
	{
		if(strlen(cfg->kvlist[i].keystr)==0)
			continue;
		if(strcasecmp (cfg->kvlist[i].keystr,keystr)==0)
		{
			memset(cfg->kvlist[i].keystr,0,32);
			break;
		}
	}
	cfg->keycnt--;
	return 0;
}


int GetLocalEthnet(Eth0Info *info)
{
	char buf[256];
	int ret=0;
	int cnt=0;
	char *ptr=NULL;
	//printf("open :%s \n",ETH0_CFG);
	int fd=open(ETH0_CFG,O_RDWR);
	if(fd<0)
	{
		Eth0Info defaultEth0;
		printf("open[%s]:error\n",ETH0_CFG);
		memset(&defaultEth0,0,sizeof(Eth0Info));
		sprintf(defaultEth0.gw,"192.168.1.1");
		sprintf(defaultEth0.netmask,"255.255.255.0");
		sprintf(defaultEth0.ip,"192.168.1.135");
		//SetLocalEthnet(&defaultEth0);
		return ;
	}
	ptr=buf;
	memset(buf,0,sizeof(buf));
	do{
		ret=read(fd,ptr,1);
		//DEBUG("addr[%08x]=%c\n",ptr,*ptr);
		if(ret!=1)
		{
			//printf("read:%m\n");
			break;
		}
		if(*ptr=='\n')
		{
			//DEBUG("read  :\\n\n");
			char key[64],val[64];
			if(buf[0]=='#')
				continue;
			if((ptr-buf)<3)
			{
				continue;
			}
			//
			ret=sscanf(buf,"%[^=]=%[^\n]\n",key,val);
			if(ret!=2)
			{
				printf("ret(%d)  , str[%s]\n",ret,buf);
				return 0;
			}
			//Trim(key);
			//Trim(val);
			//DEBUG("GetLocalEthnet read: %s  key(%s) val(%s) \n",buf,key,val);
			if(strlen(val)>16)
				continue;
			if(!strcasecmp(key,"IPADDRESS"))
			{				
				sprintf(info->ip,"%s",val);
				cnt++;		
			}
			if(!strcasecmp(key,"NETMASK"))
			{
				sprintf(info->netmask,"%s",val);
				cnt++;
			}
			if(!strcasecmp(key,"GATEWAY"))
			{
				sprintf(info->gw,"%s",val);
				cnt++;
			}
			//
			memset(buf,0,sizeof(buf));
			ptr=buf;
		}else
		ptr++;
	}while(1);
	close(fd);
	//GetMac(info->mac,sizeof(info->mac));
	//printf("eth0 ip:%s  netmask:%s  gateway:%s\n",info->ip,info->netmask,info->gw);
	if(cnt==3)
		return 0;
	return -1;
}
/*
DHCP=no
INTERFACE=eth0
IPADDRESS=192.168.1.131
NETMASK=255.255.255.0
GATEWAY=192.168.1.1
*/

int SetLocalEthnet(Eth0Info *info)
{
	char buf[256];
	int ret=0;
	char *ptr=NULL;
	int fd=open(ETH0_CFG,O_RDWR|O_TRUNC);
	if(fd<0)
	{
		printf("open[%s]:%m\n",ETH0_CFG);
		return -1;
	}
	//if(CheckIfIpaddr(info->ip)==-1)
	if (0)
	{
		printf("check_if_ipaddr [%s] \n",info->ip);
		return -1;
	}
	printf("SetLocalEthnet start ip(%s) \n",info->ip);
	lseek(fd,0,SEEK_SET);
	memset(buf,0,sizeof(buf));
	sprintf(buf,"DHCP=no\n");
	write(fd,buf,strlen(buf));
	memset(buf,0,sizeof(buf));
	sprintf(buf,"INTERFACE=eth0\n");
	write(fd,buf,strlen(buf));
	memset(buf,0,sizeof(buf));
	sprintf(buf,"IPADDRESS=%s\n",info->ip);
	write(fd,buf,strlen(buf));
	memset(buf,0,sizeof(buf));
	sprintf(buf,"NETMASK=%s\n",info->netmask);
	write(fd,buf,strlen(buf));
	memset(buf,0,sizeof(buf));
	sprintf(buf,"GATEWAY=%s\n",info->gw);
	write(fd,buf,strlen(buf));
	close(fd);
	//system("/bin/sh /etc/init.d/S80network restart");
	//fflush(stdout);
	return 0;
}
int LoadDefault(FileInitCfg *cfg)
{
	char buf[64];
	cfg->keycnt=0;
	// 0
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%s",NET_PROTOCOL_UDP);
	addCfgkey(cfg,OPTION_SIP_NETPROTOCOL,buf);
	addCfgkey(cfg,OPTION_SOFTWARE_MANUFACTURER,"kunlun");
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%sT%s",__DATE__,__TIME__);
	addCfgkey(cfg,OPTION_SOFTWARE_VERSION,buf);
	memset(buf,0,sizeof(buf));
	//GetMac(buf,sizeof(buf));
	addCfgkey(cfg,OPTION_DEVICE_MACADDR,buf);
	// 1
	addCfgkey(cfg,OPTION_SIP_LOCAL_DEVICEID,"44000103561310003301");
	memset(buf,0,sizeof(buf));
	Eth0Info ethcfg;
	GetLocalEthnet(&ethcfg);
	addCfgkey(cfg,OPTION_SIP_LOCAL_IP,ethcfg.ip);
	addCfgkey(cfg,OPTION_SIP_LOCAL_PORT,"5060");
	addCfgkey(cfg,OPTION_SIP_LOCAL_REAML,"34020000");
	
	addCfgkey(cfg,OPTION_SIP_LOCAL_PASSWD,"12345678");
	addCfgkey(cfg,OPTION_SIP_ADDR_NAME,"�Խ���");
	addCfgkey(cfg,OPTION_WEB_LOCAL_USERNAME,"admin");
	addCfgkey(cfg,OPTION_WEB_LOCAL_PASSWD,"123456");
	// 2
	#if 0
	addCfgkey(cfg,OPTION_DIRECTLY_UAS_IP,"192.168.1.138");
	addCfgkey(cfg,OPTION_DIRECTLY_UAS_EXPIRY,"3600");
	addCfgkey(cfg,OPTION_DIRECTLY_UAS_PORT,"5060");
	addCfgkey(cfg,OPTION_DIRECTLY_UAS_REAML,"34020000");
	addCfgkey(cfg,OPTION_DIRECTLY_UAS_PASSWD,"12345678");
	addCfgkey(cfg,OPTION_DIRECTLY_UAS_ID,"44000103561310001009");
	addCfgkey(cfg,OPTION_DIRECTLY_UAS_LEVEL,"0");
	addCfgkey(cfg,OPTION_DIRECTLY_UAS_HEART,"10");

	addCfgkey(cfg,OPTION_SQL_UAS_IP,"110.114.7.14");
	addCfgkey(cfg,OPTION_SQL_UAS_EXPIRY,"3600");
	addCfgkey(cfg,OPTION_SQL_UAS_PORT,"5060");
	addCfgkey(cfg,OPTION_SQL_UAS_REAML,"34020000");
	addCfgkey(cfg,OPTION_SQL_UAS_PASSWD,"12345678");
	addCfgkey(cfg,OPTION_SQL_UAS_ID,"44000103562060000001");
	addCfgkey(cfg,OPTION_SQL_UAS_LEVEL,"0");
	addCfgkey(cfg,OPTION_SQL_UAS_HEART,"9");
	#endif
	// broadcast 
	addCfgkey(cfg,OPTION_BROADCAST_PORT,"1000");
	
	// 3
	addCfgkey(cfg,OPTION_TIMER_INTERVEL,"10");
	addCfgkey(cfg,OPTION_SESSION_INTERVAL_SECOND,"10");
	// 12
	//addCfgkey(cfg,"vi0Id","44000103561310000022");
	// 13
	//addCfgkey(cfg,"vi0Name","vi0");
	
	/**********************mpp vi****************************/
	// 16 
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",0);
	addCfgkey(cfg,"mpp.vi.enNorm",buf);
	// 17
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",0);
	addCfgkey(cfg,"mpp.vi.enViMode",buf);
	// 18
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",0);
	addCfgkey(cfg,"mpp.vi.pixelFormat",buf);
	// 19
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",0);
	addCfgkey(cfg,"mpp.vi.enWDRMode",buf);
	// 20 
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",0);
	addCfgkey(cfg,"mpp.vi.enFrmRate",buf);

	/**********************mpp vi****************************/
	// 21
	addCfgkey(cfg,"mpp.venc0.venchn","0");
	// 22
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",0);
	addCfgkey(cfg,"mpp.venc0.codectype",buf);
	// 23
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",0);
	addCfgkey(cfg,"mpp.venc0.picsize",buf);
	// 24
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",0);
	addCfgkey(cfg,"mpp.venc0.enRcMode",buf);
	// 25
	addCfgkey(cfg,"mpp.venc0.u32Profile","0");
	// 26
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",0);
	addCfgkey(cfg,"mpp.venc0.rotate",buf);
	// 27
	addCfgkey(cfg,"mpp.venc0.VpssGrp","0");
	// 28
	addCfgkey(cfg,"mpp.venc0.VpssChn","0");
	// 29
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",0);
	addCfgkey(cfg,"mpp.vi.picsize",buf);
	// 30
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",1080);
	addCfgkey(cfg,"mpp.vpss.gpr0.Heigh",buf);
	
	// 31
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",1920);
	addCfgkey(cfg,"mpp.vpss.gpr0.Width",buf);
	// 32
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",0);
	addCfgkey(cfg,"mpp.vpss.gpr0.grp",buf);
	// 33
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",1080);
	addCfgkey(cfg,"mpp.vpss.gpr0.vchn0.Heigh",buf);
	// 34
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",1920);
	addCfgkey(cfg,"mpp.vpss.gpr0.vchn0.Width",buf);
	// 35
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",0);
	addCfgkey(cfg,"mpp.vpss.gpr0.vchn0.chn",buf);
	//
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",300);
	addCfgkey(cfg,OPTION_ADC_NIGHT_VALUE,buf);
	//
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",3);
	addCfgkey(cfg,OPTION_ADC_SAMPLE_INTERVEL,buf);

	// ai
	memset(buf,0,sizeof(buf));
	sprintf(buf,"%d",0);
	addCfgkey(cfg,OPTION_DEFAULT_AI_PLAYLOAD,buf);

	// save
	InitFile_SaveConfig(cfg);
	return cfg->keycnt;
}

int InitFile_Load(char *cfgPath)
{
	char buf[256];
	int ret=0,cnt=0;
	char *ptr=NULL;
	memset(&gFileInitCfg,0,sizeof(gFileInitCfg));
	sprintf(gFileInitCfg.cfgPath,"%s%s",cfgPath,"config.ini");
	int fd=open(gFileInitCfg.cfgPath,O_RDWR);
	if(fd<0)
	{
		printf("open[%s]:%m\n",gFileInitCfg.cfgPath);
		return -1;
	}
	ptr=buf;
	memset(buf,0,sizeof(buf));
	//
	memset(gFileInitCfg.kvlist,0,sizeof(KeyVal)*32);
	gFileInitCfg.keycnt=0;
	do{
		ret=read(fd,ptr,1);
		if(ret!=1)
		{
			//ERROR("read[%s]:read finish \n",cfg->cfgPath);
			break;
		}
		if(*ptr=='\n')
		{
			if(buf[0]=='#')
				continue;
			if(praseKeyVal(buf,&gFileInitCfg)>0)
			cnt++;
			memset(buf,0,sizeof(buf));
			ptr=buf;
		}else
		ptr++;
	}while(1);
	close(fd);
	return cnt;
}

int InitFile_SaveConfig()
{
	char buf[256];
	int ret=0,i=0;

	int fd=open(gFileInitCfg.cfgPath,O_RDWR|O_TRUNC);
	if(fd<0)
	{
		fd=open(gFileInitCfg.cfgPath,O_RDWR|O_CREAT,0666);
		if(fd<0)
		{
			printf("open[%s]:%m \n",gFileInitCfg.cfgPath);
			return fd;
		}
	}
	
	memset(buf,0,sizeof(buf));
	for(i=0;i<gFileInitCfg.keycnt;i++)
	{
		if(strlen(gFileInitCfg.kvlist[i].keystr)==0)
			continue;
		sprintf(buf,"%s = %s \n",gFileInitCfg.kvlist[i].keystr,gFileInitCfg.kvlist[i].valstr);
		printf("%s\n",buf);
		ret=write(fd,buf,strlen(buf));
		if(ret!=strlen(buf))
		{
			printf("write(%s): %m \n",gFileInitCfg.cfgPath);
			break;
		}
	}
	close(fd);
	return i;
}

int InitFile_ChangeConfigVal(char *dstkey ,char *value,int valuelen)
{
	int i=0;
	if(valuelen>63)
		return -1;
	for(i=0;i<gFileInitCfg.keycnt;i++)
	{
		if(strcmp(gFileInitCfg.kvlist[i].keystr,dstkey)==0)
		{
			
			sprintf(gFileInitCfg.kvlist[i].valstr,"%s",value);
			return 1;
		}
	}
	return 0;
}

char* InitFile_FindConfigKey(char *keystr)
{
	int i=0;
	KeyVal *kv=NULL;
	for(i=0;i<gFileInitCfg.keycnt;i++)
	{
		if(strlen(gFileInitCfg.kvlist[i].keystr)==0)
			continue;
		if(strcasecmp (gFileInitCfg.kvlist[i].keystr,keystr)==0)
		{
			kv=&gFileInitCfg.kvlist[i];
			return kv->valstr;
		}
	}
	return NULL;
}

