#include <stdio.h>
#include "initFileConfig.h"
#include "kunlun-string.h"

char htmls[][256] = {
	"<!DOCTYPE html>\n",
	"<html lang=\"en\">\n",
	"<head>\n",
	"    <meta charset=\"UTF-8\">\n",
	"    <title>网络配置</title>\n",
	"    <meta name=\"renderer\" content=\"webkit\">\n",
	"    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">\n",
	"    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\">\n",
	"    <meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black\">\n",
	"    <meta name=\"apple-mobile-web-app-capable\" content=\"yes\">\n",
	"    <meta name=\"format-detection\" content=\"telephone=no\">\n",
	"    <link rel=\"icon\" href=\"../image/favicon.ico\" type=\"image/x-icon\">\n",
	"    <link rel=\"stylesheet\" href=\"../css/resets.css\">\n",
	"    <link rel=\"stylesheet\" href=\"../css/inter.css\">\n",
	"    <script type=\"text/javascript\" src=\"../src/jquery-1.8.0.min.js\"></script>\n",
	"    <script>\n",
	"        $(function(){\n",
	"            // ip,掩码，网关校验\n",
	"            $(':input[name=\"id\"],:input[name=\"mask\"],:input[name=\"gateway\"]').blur(function(){\n",
	"                var obj = $(this),reg = /^((25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))$/;\n",
	"                checkForm(reg,obj);\n",
	"            });\n",
	"\n",
	"            // 校验方法\n",
	"            function checkForm(reg,obj){\n",
	"                var ovalue = $(obj).val();\n",
	"                if(!reg.test(ovalue)){\n",
	"                    $(obj).next().show();\n",
	"                }else{\n",
	"                    $(obj).next().hide();\n",
	"                }\n",
	"            }\n",
	"            // 保存按钮点击监听事件\n",
	"            $('.save').click(function(){\n",
	"                $(':input[name=\"id\"],:input[name=\"mask\"],:input[name=\"gateway\"]').blur();\n",
	"                if($('.error').css('display') == 'none'){\n",
	"                     $(this).each (function() { this.type = 'submit' });\n",
	"                }\n",
	"            });\n",
	"\n",
	"            // 复选框按钮点击事件监听\n",
	"            $('.moveIp span').click(function(){\n",
	"                $(this).toggleClass('checked');\n",
	"                var name = this.className;\n",
	"                return checks(name);\n",
	"            });\n",
	"            function checks(type) {\n",
	"                if (type == 'checked') {\n",
	"                    $(':input[type=\"text\"]').attr('readonly', 'readonly');\n",
	"                } else {\n",
	"                    $(':input[type=\"text\"]').removeAttr('readonly');\n",
	"                }\n",
	"            }\n",
	"        });\n",
	"    </script>\n",
	"</head>\n",
	"\n",
	"<body>\n",
	"    <div class=\"inter-containter\">\n",
	"        <div class=\"userChoose\">\n",
	"            <div class=\"moveIp\">动IP501<span class=\"checked\"></span></div>\n",
	"            <div class=\"staticIp\">静态IP502<span class=\"checked\"></span></div>\n",
	"        </div>\n",
	"		<form class=\"setforms\" action=\"/cgi-bin/interSet-save.cgi\" method=\"post\">\n",
	"            <div class=\"inputs\" style=\"overflow: hidden;\">\n",
	"                <div class=\"set-group\">\n",
	"                    <label for=\"\">IP：</label>\n",
	"                    <input type=\"text\" name=\"ip\" readonly=\"readonly\" value=\"%s\">\n",
	"                    <p class=\"error\">IP地址格式不正确503（例如：192.168.1.202）</p>\n",
	"                </div>\n",
	"                <div class=\"set-group\">\n",
	"                    <label for=\"\">掩码504：</label>\n",
	"                    <input type=\"text\" name=\"mask\" readonly=\"readonly\" value=\"%s\">\n",
	"                    <p class=\"error\">掩码格式不正确505（例如：255.255.255.0）</p>\n",
	"                </div>\n",
	"                <div class=\"set-group\">\n",
	"                    <label for=\"\">网关506：</label>\n",
	"                    <input type=\"text\" name=\"gateway\" readonly=\"readonly\" value=\"%s\">\n",
	"                    <p class=\"error\">网关格式不正确507（例如：192.168.1.154）</p>\n",
	"                </div>\n",
	"            </div>\n",
	"            <div class=\"btns\">\n",
	"                <button class=\"save\" type=\"submit\">保存102</button>\n",
	"                <button class=\"cancel\" type=\"reset\">取消</button>\n",
	"            </div>\n",
	"        </form>\n",
	"    </div>\n",
	"</body>\n",
	"</html>"
};

#define GET_ARRAY_LEN(array,len){len = (sizeof(array) / sizeof(array[0]));}

int main()
{
	printf("Content-type:text/html\n\n"); //这句一定要加上

	// add other html elements.
	int nRet = InitFile_Load("/opt/app/");
	//printf("InitFile_Load(/opt/app/) return %d.\n", nRet);

	/*
	   char* kunlun_ip_ini_ptr = InitFile_FindConfigKey("sip.local.ip");
	   char* kunlun_mask_ini_ptr = InitFile_FindConfigKey("sip.local.mask");
	   char* kunlun_gateway_ini_ptr = InitFile_FindConfigKey("sip.local.gateway");
	   char* kunlun_ip_ptr = rtrim(kunlun_ip_ini_ptr);
	   char* kunlun_mask_ptr = rtrim(kunlun_mask_ini_ptr);
	   char* kunlun_gateway_ptr = rtrim(kunlun_gateway_ini_ptr);
	 */

	//int GetLocalEthnet(Eth0Info *info);
	Eth0Info info;
	nRet = GetLocalEthnet(&info);
	//printf("GetLocalEthnet(&info) return %d.\n", nRet);

	char* kunlun_ip_ptr = rtrim(info.ip);
	char* kunlun_mask_ptr = rtrim(info.netmask);
	char* kunlun_gateway_ptr = rtrim(info.gw);

	int arr_len;
	GET_ARRAY_LEN(htmls,arr_len)
		//printf("GET_ARRAY_LEN is：%d.\n", arr_len);	// 47

		int i;
	for (i = 0; i < arr_len; i++)
	{
		if (74-7 == i)
		{	// ip
			printf(htmls[i], kunlun_ip_ptr);
		}
		else if (79-7 == i)
		{	// mask
			printf(htmls[i], kunlun_mask_ptr);
		}
		else if (84-7 == i)
		{	// gateway
			printf(htmls[i], kunlun_gateway_ptr);
		}
		else
		{
			printf(htmls[i]);
		}
	}

	return 0;
}
