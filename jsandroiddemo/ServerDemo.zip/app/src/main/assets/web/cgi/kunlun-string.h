#ifndef __KUNLUN_STRING_H__
#define __KUNLUN_STRING_H__

//去除尾部空白字符 包括\t \n \r  
/*
标准的空白字符包括：
' '     (0x20)    space (SPC) 空格符
'\t'    (0x09)    horizontal tab (TAB) 水平制表符    
'\n'    (0x0a)    newline (LF) 换行符
'\v'    (0x0b)    vertical tab (VT) 垂直制表符
'\f'    (0x0c)    feed (FF) 换页符
'\r'    (0x0d)    carriage return (CR) 回车符
//windows \r\n linux \n mac \r
*/
char *rtrim(char *str);

//去除首部空格
char *ltrim(char *str);

//去除首尾空格
char *trim(char *str);

#endif	// #define __KUNLUN_STRING_H__
