package com.example.serverdemo.controller;


import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.example.serverdemo.model.UserInfo;
import com.yanzhenjie.andserver.annotation.GetMapping;
import com.yanzhenjie.andserver.annotation.RequestMapping;
import com.yanzhenjie.andserver.annotation.RestController;

@RestController
@RequestMapping(path = "/item")
public class ItemController {

    //不在同一个页面的html  需要另起炉灶才行
    //get请求
    @GetMapping(path = "/status", produces = {"application/json; charset=utf-8"})
    String message() {
        Log.e("TAG", "TestController=status: ");
        UserInfo userInfo=new UserInfo();
        userInfo.setUserName("status");
        userInfo.setUserId("NO.201");
        return JSON.toJSONString(userInfo);

    }

}
