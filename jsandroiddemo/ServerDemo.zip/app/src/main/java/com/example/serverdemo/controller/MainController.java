package com.example.serverdemo.controller;


import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.example.serverdemo.model.InterinfoData;
import com.example.serverdemo.model.ReturnData;
import com.example.serverdemo.model.UserInfo;
import com.example.serverdemo.util.JsonUtils;
import com.google.gson.Gson;
import com.yanzhenjie.andserver.annotation.GetMapping;
import com.yanzhenjie.andserver.annotation.RequestMapping;
import com.yanzhenjie.andserver.annotation.RestController;

@RestController
@RequestMapping(path = "/main")
public class MainController {


    @GetMapping(path = "/interinfo", produces = {"application/json; charset=utf-8"})
    String interinfo() {
        InterinfoData mInterinfoData = new InterinfoData();
        mInterinfoData.setDevice_ip("192.168.1.167");
        mInterinfoData.setDevice_netmask("255.255.255.0");
        mInterinfoData.setDevice_gateway("192.168.1.1");
        mInterinfoData.setDevice_mac("00:1c:c8:16:00:55");
        Gson gson = new Gson();
        String userJson = gson.toJson(mInterinfoData);
        Log.e("TAG", "MainController=interinfo: "+mInterinfoData.toString());
        return userJson;
    }


    //不在同一个页面的html  需要另起炉灶才行  还是不行啊  没有任何反应
    //get请求  已经拿到了网页端发送过来的数据  保存静态ip
    @GetMapping(path = "/intersave", produces = {"application/json; charset=utf-8"})
    String intersave() {
        ReturnData mReturnData = new ReturnData();
        mReturnData.setMessage("成功");
        mReturnData.setCode("200");
        Gson gson = new Gson();
        String userJson = gson.toJson(mReturnData);
        Log.e("TAG", "MainController=intersave: "+userJson);
        return userJson;
    }

}
