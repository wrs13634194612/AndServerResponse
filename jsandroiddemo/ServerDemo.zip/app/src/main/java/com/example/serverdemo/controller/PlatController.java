package com.example.serverdemo.controller;

import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.example.serverdemo.model.InterinfoData;
import com.example.serverdemo.model.ReturnData;
import com.example.serverdemo.model.UserInfo;
import com.example.serverdemo.util.JsonUtils;
import com.google.gson.Gson;
import com.yanzhenjie.andserver.annotation.GetMapping;
import com.yanzhenjie.andserver.annotation.RequestMapping;
import com.yanzhenjie.andserver.annotation.RestController;

@RestController
@RequestMapping(path = "/views/plat")
public class PlatController {

    //获取状态开关
    @GetMapping(path = "/portstatus", produces = {"application/json; charset=utf-8"})
    String portstatus() {
        return "portstatus";
    }

    //获取平台信息
    @GetMapping(path = "/platsetinfo", produces = {"application/json; charset=utf-8"})
    String platsetinfo() {
        return "platsetinfo";
    }

    //保存平台信息
    @GetMapping(path = "/platsave", produces = {"application/json; charset=utf-8"})
    String platsave() {
        return "platsave";
    }

    //关闭终端服务端口开关
    @GetMapping(path = "/portclose", produces = {"application/json; charset=utf-8"})
    String portclose() {
        return "portclose";
    }

    //打开终端服务端口开关
    @GetMapping(path = "/portopen", produces = {"application/json; charset=utf-8"})
    String portopen() {
        return "portopen";
    }
}
