package com.example.serverdemo.controller;


import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.example.serverdemo.model.InterinfoData;
import com.example.serverdemo.model.ReturnData;
import com.example.serverdemo.model.UserInfo;
import com.example.serverdemo.util.JsonUtils;
import com.google.gson.Gson;
import com.yanzhenjie.andserver.annotation.GetMapping;
import com.yanzhenjie.andserver.annotation.RequestMapping;
import com.yanzhenjie.andserver.annotation.RestController;

@RestController
@RequestMapping(path = "/views/server")
public class ServerController {

    @GetMapping(path = "/serverinfo", produces = {"application/json; charset=utf-8"})
    String serverinfo() {
        return "serverinfo";
    }


    @GetMapping(path = "/serversave", produces = {"application/json; charset=utf-8"})
    String serversave() {
        return "serversave";
    }

    @GetMapping(path = "/registered", produces = {"application/json; charset=utf-8"})
    String registered() {
        return "registered";
    }

}
