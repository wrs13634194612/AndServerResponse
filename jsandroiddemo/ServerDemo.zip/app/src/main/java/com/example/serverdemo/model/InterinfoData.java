package com.example.serverdemo.model;


import android.os.Parcel;
import android.os.Parcelable;

import com.alibaba.fastjson.annotation.JSONField;

public class InterinfoData implements Parcelable {

    @JSONField(name = "Device_ip")
    private String Device_ip;

    @JSONField(name = "Device_netmask")
    private String Device_netmask;

    @JSONField(name = "Device_gateway")
    private String Device_gateway;

    @JSONField(name = "Device_mac")
    private String Device_mac;

    public InterinfoData() {
    }

    protected InterinfoData(Parcel in) {
        Device_ip = in.readString();
        Device_netmask = in.readString();
        Device_gateway = in.readString();
        Device_mac = in.readString();
    }

    @Override
    public String toString() {
        return "InterinfoData{" +
                "Device_ip='" + Device_ip + '\'' +
                ", Device_netmask='" + Device_netmask + '\'' +
                ", Device_gateway='" + Device_gateway + '\'' +
                ", Device_mac='" + Device_mac + '\'' +
                '}';
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(Device_ip);
        dest.writeString(Device_netmask);
        dest.writeString(Device_gateway);
        dest.writeString(Device_mac);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ReturnData> CREATOR = new Creator<ReturnData>() {
        @Override
        public ReturnData createFromParcel(Parcel in) {
            return new ReturnData(in);
        }

        @Override
        public ReturnData[] newArray(int size) {
            return new ReturnData[size];
        }
    };

    public String getDevice_ip() {
        return Device_ip;
    }

    public void setDevice_ip(String device_ip) {
        Device_ip = device_ip;
    }

    public String getDevice_netmask() {
        return Device_netmask;
    }

    public void setDevice_netmask(String device_netmask) {
        Device_netmask = device_netmask;
    }

    public String getDevice_gateway() {
        return Device_gateway;
    }

    public void setDevice_gateway(String device_gateway) {
        Device_gateway = device_gateway;
    }

    public String getDevice_mac() {
        return Device_mac;
    }

    public void setDevice_mac(String device_mac) {
        Device_mac = device_mac;
    }
}