#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/select.h> 
#include <sys/stat.h>  
#include <unistd.h>
#include <pthread.h>
#include "SocketRpc.h"
#include "SocketUtil.h"
#include <netinet/in.h>
#include <arpa/inet.h>
//#include"printf.h"

int SocketRpcCreateServer(char* ipaddr,int bindport,int protocol)
{
	int ret = SocketCreateServer(ipaddr,bindport,protocol);
	if(ret<0)
	{
		printf("SocketRpcCreateServer printf:pid%d\r\n",getpid());
		
		//system("ps");
		//system("reboot");
	}	
	return ret;
}

int SocketRpcConnect(char* ipaddr,int port, int protocol)
{
	return ConnectToCenter(ipaddr,port,protocol);
}

int SocketRpcMsgSend(int SocketFd,int cmd,void* data, int data_len)
{
	SocketRpcMsg* msg;
	char RpcSendBuffer[sizeof(SocketRpcMsg)+MAX_SOCKET_RPC_DATA_LEN];
	int ret =-1 ;
	char *MallocBuffer=NULL ;
	//printf("---- SocketRpcMsgSend  send  datalen=%d cmd=%d  \n",data_len,cmd);
	if(SocketFd < 0)
	{
		printf("param err\r\n");
		return -1;
	}
	
	if(data_len > MAX_SOCKET_RPC_DATA_LEN)
	{
		MallocBuffer = malloc(sizeof(SocketRpcMsg)+data_len);
		if(MallocBuffer==NULL)
			return -1;
		msg = (SocketRpcMsg*)MallocBuffer;	
	}
	else
	{
		msg = (SocketRpcMsg*)RpcSendBuffer;
	}
	
	msg->cmd = cmd;
	if(data_len>0)
		memcpy(&msg->data[0], data, data_len);
	msg->DataLen= data_len;
	
	ret = SocketDataSend(SocketFd,msg,data_len+sizeof(SocketRpcMsg));
	
//	printf("----send  datalen=%d cmd=%d  send ret=%d\n",data_len,cmd,ret);
	if(MallocBuffer!=NULL)
	{
		free(MallocBuffer);
	}

	if(ret<=0)
	
	{
		struct sockaddr_in addr ;
		int addrlen ;
		addrlen = sizeof(struct sockaddr_in);
		if(getpeername(SocketFd,(struct sockaddr*)&addr,(socklen_t*)&addrlen)==0)
		{
			printf("����SocketRpcSendMsg printf����:port=%d\r\n",ntohs(addr.sin_port));
		}
		else
		{
			printf("getpeername:%m\r\n");
		}
		printf("SocketRpcSendMsg %d err\r\n",cmd);
	}
	return ret;
}

int SocketRpcMsgSendto(int SocketFd,char * RemoteAddr,int RemotePort,SocketRpcMsg* msg)
{
	if(msg==NULL)
		return -1;
	int ret = SocketDataSendTo(SocketFd,(void *)msg,msg->DataLen+sizeof(SocketRpcMsg),RemoteAddr,RemotePort);
	return ret;
}

int SocketRpcRecv(int fd,char* DataBuf, int bufsize)
{
	int Ret;

	Ret = SocketDataRecv(fd,DataBuf,bufsize);
	return Ret;	
}


int SocketRpcRecvWait(int fd,char* DataBuf, int bufsize,int timeout_ms)
{
	fd_set TotalFDSet;
	struct timeval tv;

	tv.tv_sec = timeout_ms/1000;
	tv.tv_usec = timeout_ms%1000*1000;

	FD_ZERO(&TotalFDSet);
	FD_SET(fd,&TotalFDSet);	
	if(select(fd+1,&TotalFDSet,NULL,NULL,&tv) < 0)
	{
		//printf("SocketRpcRecvWait select printf\r\n");
		return -1;
	}
	if(FD_ISSET(fd,&TotalFDSet))	
	{
		return SocketRpcRecv(fd,DataBuf,bufsize);
	}
	else
	{
		//printf("SocketRpcRecvWait  FD_ISSET printf\r\n");
		return 0;
	}
}

int SocketRpcRecvFrom(int fd,char* DataBuf, int bufsize,char* RemoteAddr, int* RemotePort)
{
	int Ret;

	Ret = SocketDataRecvFrom(fd,DataBuf,bufsize,RemoteAddr,RemotePort);
	return Ret;	
}


int SocketRpcRecvFromWait(int fd,char* DataBuf, int bufsize,char* RemoteAddr, int* RemotePort,int timeout_ms)
{
	fd_set TotalFDSet;
	struct timeval tv;

	tv.tv_sec = timeout_ms/1000;
	tv.tv_usec = timeout_ms%1000*1000;

	FD_ZERO(&TotalFDSet);
	FD_SET(fd,&TotalFDSet);	
	if(select(fd+1,&TotalFDSet,NULL,NULL,&tv) < 0)
	{
		printf("SocketRpcRecvFromWait select printf :%m\r\n");
		return -1;
	}
	if(FD_ISSET(fd,&TotalFDSet))	
	{
		int Ret = SocketDataRecvFrom(fd,DataBuf,bufsize,RemoteAddr,RemotePort);
		//printf("SocketDataRecvFrom !!!\n");
		return Ret ;
	}
	else
	{
		//printf("time out !!!\n");
		return 0;
	}
}

int SocketRpcMsgRcvWait(int fd,int cmdid,char* pdata, int bytes,int timeout_ms)
{
	int ret;
	char buffer[sizeof(SocketRpcMsg)+MAX_SOCKET_RPC_DATA_LEN];
	char *mallocbuffer = NULL;
	char *pbuf;
	if(bytes>MAX_SOCKET_RPC_DATA_LEN)
	{
		mallocbuffer = malloc(sizeof(SocketRpcMsg)+bytes);
		if(mallocbuffer==NULL)return -1;
		pbuf = mallocbuffer ;
	}
	else
	{
		pbuf = buffer ;
	}
	SocketRpcMsg *rmsg = (SocketRpcMsg *)pbuf;
	ret = SocketRpcRecvWait(fd,pbuf,sizeof(SocketRpcMsg)+bytes,timeout_ms);
	if(ret>=(int)(sizeof(SocketRpcMsg)))
	{
		if(rmsg->cmd == (int)cmdid)
		{
			if(((unsigned)ret-sizeof(SocketRpcMsg))>0)
				memcpy(pdata,rmsg->data,(unsigned)ret-sizeof(SocketRpcMsg));
			ret = ret-(int)sizeof(SocketRpcMsg);
		}
		else
		{
			printf("����SocketRpcMsgRcv cmd printf����:cmd=%d,ret =%d cmd=%d\r\n",cmdid,ret,rmsg->cmd);
			ret = -1;
		}
	}
	else
	{
		printf("����SocketRpcMsgRcv printf����:cmd=%d,ret=%d\r\n",cmdid,ret);
		ret = -1;
	}
	if(ret == -1)
	{
		struct sockaddr_in addr ;
		int addrlen ;
		addrlen = sizeof(struct sockaddr_in);
		if(getpeername(fd,(struct sockaddr*)&addr,(socklen_t*)&addrlen)==0)
		{
			printf("����SocketRpcMsgRcv printf����:port=%d\r\n",ntohs(addr.sin_port));
		}
		else
		{
			printf("getpeername:%m\r\n");
		}
		
	}
	if(mallocbuffer!=NULL)free(mallocbuffer);
	return ret;
}

int SocketRpcSendToClient(int fd,char* RemoteAddr,unsigned int RemotePort,int cmd,void *pdata,int len)
{
	char RPCMsgSendBuffer[sizeof(SocketRpcMsg)+MAX_SOCKET_RPC_DATA_LEN];
	if((unsigned)len>MAX_SOCKET_RPC_DATA_LEN)
		return -1;
	SocketRpcMsg *sendrpc = (SocketRpcMsg*)RPCMsgSendBuffer ;
	sendrpc->cmd = cmd;
	sendrpc->DataLen = len;
	if(len>0)
		memcpy(sendrpc->data,pdata,len);
	int ret = SocketRpcMsgSendto(fd,RemoteAddr,RemotePort,sendrpc);
	return ret ;
}


int LocalClientRpcConnect(int port)//
{
	return SocketRpcConnect(LO_IP_ADDR,port,SOCK_DGRAM);
}

int SocketClientRpcSend(int fd,int CmdId,void *pdata,int len)
{
	return SocketRpcMsgSend(fd,CmdId,pdata,len);
}

int SocketClientRpcRcv(int fd,int cmdid,char* pdata, int bytes)
{
	int ret = SocketRpcMsgRcvWait(fd,cmdid,pdata,bytes,1000);
	return ret;
}

int SocketClientRcvAck(int fd,int cmdid)
{
	char ack;
	int ret = SocketClientRpcRcv(fd,cmdid,&ack,1);
	if(ret<=0)return -1;
	return (int)ack ;
}

