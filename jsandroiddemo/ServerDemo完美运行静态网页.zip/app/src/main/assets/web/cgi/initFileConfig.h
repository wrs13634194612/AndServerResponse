#ifndef __INIT_FILE_CONFIG_H__
#define __INIT_FILE_CONFIG_H__

#define MAX_LEN 64

#define MPP_AUDIO_SAMPLERATE     "mpp.audio.samplerate"
#define MPP_AUDIO_BITWIDTH       "mpp.audio.bitwidth"


#define MPP_VI_ENNORM       "mpp.vi.enNorm"
#define MPP_VI_ENVIMODE     "mpp.vi.enViMode"
#define MPP_VI_PIXELFORMAT  "mpp.vi.pixelFormat"
#define MPP_VI_ENWDRMODE    "mpp.vi.enWDRMode"
#define MPP_VI_FRMRATE      "mpp.vi.enFrmRate"
#define MPP_VENC0_CODECTYPE "mpp.venc0.codectype"
#define MPP_VENC0_PICSIZE   "mpp.venc0.picsize"
#define MPP_VENC0_RCMODE    "mpp.venc0.enRcMode"
#define MPP_VENC0_PROFILE   "mpp.venc0.u32Profile"
#define MPP_VENC0_ROTATE    "mpp.venc0.rotate"
#define MPP_OSD_DATE    	"mpp.osd.date"
#define MPP_OSD_ALARM    	"mpp.osd.alarm"
#define MPP_OSD_TEXT    	"mpp.osd.text"




//// adc
#define OPTION_ADC_NIGHT_VALUE 		      "adc.night.value"
#define OPTION_ADC_SAMPLE_INTERVEL        "adc.intervel.second"
// sip
#define OPTION_SIP_NETPROTOCOL            "sip.netprotocol"
#define NET_PROTOCOL_UDP  "udp"
#define NET_PROTOCOL_TCP  "tcp"

#define OPTION_SIP_LOCAL_DEVICEID         "sip.local.deviceid"
#define OPTION_SIP_LOCAL_IP               "sip.local.ip"
#define OPTION_SIP_LOCAL_PORT             "sip.local.port"
#define OPTION_SIP_LOCAL_PASSWD           "sip.local.passwd"
#define OPTION_SIP_ADDR_NAME              "sip.addr.name"
#define OPTION_SIP_LOCAL_REAML            "sip.local.reaml"
#define OPTION_SIP_LOCAL_EXPIRY           "sip.local.expiry"

#define OPTION_TIMER_INTERVEL             "timer.intervel.second"

#define OPTION_WEB_LOCAL_USERNAME         "web.local.username"
#define OPTION_WEB_LOCAL_PASSWD         "web.local.passwd"

// version
#define OPTION_SOFTWARE_VERSION           "software.version"
#define OPTION_SOFTWARE_MANUFACTURER      "software.manufacturer"
#define OPTION_DEVICE_MACADDR             "device.mac.address"
// ua

// sql 
#define OPTION_SQL_UAS_REAML   			  "sql.ua.reaml"
#define OPTION_SQL_UAS_PORT    		      "sql.ua.port"
#define OPTION_SQL_UAS_PASSWD  		      "sql.ua.passwd"
#define OPTION_SQL_UAS_ID  	   		      "sql.ua.id"
#define OPTION_SQL_UAS_LEVEL   		      "sql.ua.level"
#define OPTION_SQL_UAS_IP      		      "sql.ua.ip"
#define OPTION_SQL_UAS_EXPIRY  		      "sql.ua.expiry"
#define OPTION_SQL_UAS_HEART   		      "sql.ua.heart"
//  DIRECTLY
#define OPTION_DIRECTLY_UAS_REAML         "directly.ua.reaml"
#define OPTION_DIRECTLY_UAS_PORT          "directly.ua.port"
#define OPTION_DIRECTLY_UAS_PASSWD        "directly.ua.passwd"
#define OPTION_DIRECTLY_UAS_ID            "directly.ua.id"
#define OPTION_DIRECTLY_UAS_LEVEL         "directly.ua.level"
#define OPTION_DIRECTLY_UAS_IP            "directly.ua.ip"
#define OPTION_DIRECTLY_UAS_EXPIRY        "directly.ua.expiry"
#define OPTION_DIRECTLY_UAS_HEART         "directly.ua.heart"
// ai
#define OPTION_DEFAULT_AI_PLAYLOAD        "default.ai.playload"
// broadcast
#define OPTION_BROADCAST_PORT             "update.broadcast.port"
// 
#define OPTION_SESSION_INTERVAL_SECOND    "session.interval.second"


typedef struct KeyVal_t{
	char keystr[32];
	char valstr[64];
}KeyVal;

typedef struct Eth0Info_T{
char  ip[16];
char netmask[16];
char gw[16];
char mac[64];
}Eth0Info;

int InitFile_Load(char *cfgPath);
char* InitFile_FindConfigKey(char *keystr);
int InitFile_ChangeConfigVal(char *dstkey ,char *value,int valuelen);
int InitFile_SaveConfig();
int GetLocalEthnet(Eth0Info *info);
int SetLocalEthnet(Eth0Info *info);




#endif

