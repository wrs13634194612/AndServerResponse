﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "initFileConfig.h"
#include "SocketRpc.h"
#include "SocketUtil.h"
#include"intercomMonitor.h"

//#include <string.h>
//#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// common
int IntercomRestartNet()
{
	int fd = LocalClientRpcConnect(COMMON_AGENT_RPC_SERVER_PORT);
	printf("LocalClientRpcConnect(%d) return %d.\n", COMMON_AGENT_RPC_SERVER_PORT, fd);
	if(fd<0) return -1;
	int ret = SocketClientRpcSend(fd,COMMON_RESTART_NET,NULL,0);
	printf("SocketClientRpcSend(fd,%d,NULL,0) return %d.\n", COMMON_RESTART_NET, ret);
	close(fd);
	return ret ;
}

int IsValidIp(char *ip)
{
    long addr;
    
    if (inet_pton(AF_INET, ip, (void *)&addr) <= 0) {
        printf("Invalid ip address.\n");
        return 0;	// false
    }
 
    return 1;	// true
}

int IsSubnetMask(char* subnet)  
{  
    if(IsValidIp (subnet))  
    {  
        unsigned int b = 0, i, n[4];  
        sscanf(subnet, "%u.%u.%u.%u", &n[3], &n[2], &n[1], &n[0]);  
        for(i = 0; i < 4; ++i) //将子网掩码存入32位无符号整型   
            b += n[i] << (i * 8);   
        b = ~b + 1;  
        if((b & (b - 1)) == 0)   //判断是否为2^n   
            return 1;  
    }  
    return 0;  
}

int main(void){
        int len, nRet;
        char *lenstr,poststr[256];
		char kunlun_ip[256],kunlun_mask[256],kunlun_gateway[256];
        //char m[10],n[10];
		
		// add other html elements.
		nRet = InitFile_Load("/opt/app/");
		//printf("InitFile_Load(/opt/app/) return %d.\n", nRet);
		
        printf("Content-Type:text/html\n\n");
        printf("<HTML>\n");
        printf("<HEAD>\n<meta charset=\"UTF-8\">\n<TITLE >saveConfig</TITLE>\n</HEAD>\n");
        printf("<BODY>\n");
        printf("<div style=\"font-size:12px\">\n");
        lenstr = getenv("CONTENT_LENGTH");
        if(lenstr == NULL)
                printf("<DIV STYLE=\"COLOR:RED\">Error parameters should be entered!</DIV>\n");
        else{
				///*
                len=atoi(lenstr);
                fgets(poststr,len+1,stdin);
                if(sscanf(poststr,"ip=%[^&]&mask=%[^&]&gateway=%s",kunlun_ip,kunlun_mask,kunlun_gateway)!=3){
                        printf("<DIV STYLE=\"COLOR:RED\">Error: Parameters are not right! poststr: %s</DIV>\n", poststr);
						printf("<HR COLOR=\"blue\" align=\"left\" width=\"100\">");
						printf("<input type=\"button\" value=\"继续下一步\" onclick=\"javascript:window.location='interSet.cgi'\">");
                }
                else{
                       printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">kunlun_ip: %s</DIV>\n",kunlun_ip);
                       printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">kunlun_mask: %s</DIV>\n",kunlun_mask);
                       printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">kunlun_gateway: %s</DIV>\n",kunlun_gateway);
					   
					   if (IsValidIp(kunlun_ip) && IsValidIp(kunlun_gateway) && IsSubnetMask(kunlun_mask))
					   {					   
						   // int InitFile_ChangeConfigVal(char *dstkey ,char *value,int valuelen)
						   nRet = InitFile_ChangeConfigVal("sip.local.ip", kunlun_ip, strlen(kunlun_ip));
						   //nRet = InitFile_ChangeConfigVal("sip.local.mask", kunlun_mask, strlen(kunlun_mask));
						   //nRet = InitFile_ChangeConfigVal("sip.local.gateway", kunlun_gateway, strlen(kunlun_gateway));
						   // int InitFile_SaveConfig()
						   nRet = InitFile_SaveConfig();
						   
						   Eth0Info info;
						   strncpy(info.ip, kunlun_ip, sizeof(info.ip));
						   strncpy(info.netmask, kunlun_mask, sizeof(info.netmask));
						   strncpy(info.gw, kunlun_gateway, sizeof(info.gw));
						   
						   //int SetLocalEthnet(Eth0Info *info);
						   nRet = SetLocalEthnet(&info);
						   IntercomRestartNet(); // RestartNet
						   
						   printf("<DIV STYLE=\"COLOR:RED\">IP修改成功，页面即将自动跳转到新的IP.</DIV>\n");
						   //printf("<SCRIPT LANGUAGE=\"JavaScript\">window.location.href=\"http://%s\";</script>", kunlun_ip);
						   printf("<SCRIPT LANGUAGE=\"JavaScript\">top.location.href=\"http://%s\";</script>", kunlun_ip);
					   }
					   else
					   {
						    printf("<DIV STYLE=\"COLOR:RED\">Error: Invalid IP/mask/gateway.</DIV>\n");
							printf("<HR COLOR=\"blue\" align=\"left\" width=\"100\">");
							printf("<input type=\"button\" value=\"继续下一步\" onclick=\"javascript:window.location='interSet.cgi'\">");
					   }
                }	
        }
		
        printf("</div>\n");
        printf("</BODY>\n");
        printf("</HTML>\n");
        fflush(stdout);
        return 0;
}
