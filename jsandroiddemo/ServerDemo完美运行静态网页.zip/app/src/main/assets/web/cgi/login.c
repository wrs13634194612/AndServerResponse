﻿#include <stdio.h>
#include <stdlib.h>
#include "initFileConfig.h"
#include "kunlun-string.h"

int main(void){
        int len, nRet;
        char *lenstr,poststr[256];
		//char kunlun_key[256],kunlun_value[256];
		char kunlun_username[256],kunlun_password[256];
        //char m[10],n[10];
		
		// add other html elements.
		nRet = InitFile_Load("/opt/app/");
		//printf("InitFile_Load(/opt/app/) return %d.\n", nRet);
		
        printf("Content-Type:text/html\n\n");
        printf("<HTML>\n");
        printf("<HEAD>\n<meta charset=\"UTF-8\">\n<TITLE >saveConfig</TITLE>\n</HEAD>\n");
        printf("<BODY>\n");
        printf("<div style=\"font-size:12px\">\n");
        lenstr = getenv("CONTENT_LENGTH");
		//lenstr = getenv("CONTENT_LENGTH");  
        if(lenstr == NULL)
                printf("<DIV STYLE=\"COLOR:RED\">Error parameters should be entered!</DIV>\n");
        else{
				///*
                len=atoi(lenstr);
                fgets(poststr,len+1,stdin);
                if(sscanf(poststr,"username=%[^&]&password=%s",kunlun_username,kunlun_password)!=2){
                        printf("<DIV STYLE=\"COLOR:RED\">Error: Parameters are not right! poststr: %s</DIV>\n", poststr);
						printf("<HR COLOR=\"blue\" align=\"left\" width=\"100\">");
						printf("<input type=\"button\" value=\"重试登录\" onclick=\"javascript:window.location='/index.html'\">");
                }
                else{
					    //char* InitFile_FindConfigKey(char *keystr);
					    char* kunlun_username_ini_ptr = InitFile_FindConfigKey("sip.local.username");
					    char* kunlun_password_ini_ptr = InitFile_FindConfigKey("sip.local.passwd");
						char* kunlun_username_ptr = rtrim(kunlun_username_ini_ptr);
						char* kunlun_password_ptr = rtrim(kunlun_password_ini_ptr);
					    
					    printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">input_username: %s, input_password: %s.</DIV>\n",kunlun_username, kunlun_password);
					    //printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">kunlun_username_ptr: %s, kunlun_password_ptr: %s.</DIV>\n",kunlun_username_ptr, kunlun_password_ptr);
						if ((0 == strncmp(kunlun_username, kunlun_username_ptr, 64)) && (0 == strncmp(kunlun_password, kunlun_password_ptr, 64)))
						{
						    printf("<DIV STYLE=\"COLOR:RED\">登录成功，即将自动跳转到新的页面.</DIV>\n");
						    printf("<SCRIPT LANGUAGE=\"JavaScript\">window.location.href=\"/views/main.html\";</script>");

							//printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">Yes, continue please.</DIV>\n");							
							//printf("<HR COLOR=\"blue\" align=\"left\" width=\"100\">");
							//printf("<input type=\"button\" value=\"继续下一步\" onclick=\"javascript:window.location='/views/main.html'\">");
						}
						else
						{
							printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">No, retry again.</DIV>\n");
							//printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">strncmp(kunlun_username, kunlun_username_ptr, 64) return %d.</DIV>\n", strncmp(kunlun_username, kunlun_username_ptr, 64));
							//printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">strncmp(kunlun_password, kunlun_password_ptr, 64) return %d.</DIV>\n", strncmp(kunlun_password, kunlun_password_ptr, 64));
							printf("<HR COLOR=\"blue\" align=\"left\" width=\"100\">");
							printf("<input type=\"button\" value=\"重试登录\" onclick=\"javascript:window.location='/index.html'\">");
						}
                }	
        }
		
        printf("</div>\n");
        printf("</BODY>\n");
        printf("</HTML>\n");
        fflush(stdout);
        return 0;
}
