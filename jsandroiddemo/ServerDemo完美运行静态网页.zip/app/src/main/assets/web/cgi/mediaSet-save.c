﻿#include <stdio.h>
#include <stdlib.h>
#include "initFileConfig.h"

int main(void){
        int len, nRet;
        char *lenstr,poststr[256];
		char kunlun_resolution[256],kunlun_bitRate[256],kunlun_videoCoding[256],kunlun_audio_bitRate[256],kunlun_audioCoding[256];
        //char m[10],n[10];
		
		// add other html elements.
		nRet = InitFile_Load("/opt/app/");
		//printf("InitFile_Load(/opt/app/) return %d.\n", nRet);
		
        printf("Content-Type:text/html\n\n");
        printf("<HTML>\n");
        printf("<HEAD>\n<meta charset=\"UTF-8\">\n<TITLE >saveConfig</TITLE>\n</HEAD>\n");
        printf("<BODY>\n");
        printf("<div style=\"font-size:12px\">\n");
        lenstr = getenv("CONTENT_LENGTH");
        if(lenstr == NULL)
		{
                printf("<DIV STYLE=\"COLOR:RED\">Error parameters should be entered!</DIV>\n");
				printf("<HR COLOR=\"blue\" align=\"left\" width=\"100\">");
				printf("<input type=\"button\" value=\"继续下一步\" onclick=\"javascript:window.location='mediaSet.cgi'\">");
		}
        else{
				///*
                len=atoi(lenstr);
                fgets(poststr,len+1,stdin);
                if(sscanf(poststr,"resolution=%[^&]&bitRate=%[^&]&videoCoding=%[^&]&audio_bitRate=%[^&]&gateway=%s",\
					kunlun_resolution,kunlun_bitRate,kunlun_videoCoding,kunlun_audio_bitRate,kunlun_audioCoding)!=5){
                        printf("<DIV STYLE=\"COLOR:RED\">Error: Parameters are not right! poststr: %s</DIV>\n", poststr);
						printf("<HR COLOR=\"blue\" align=\"left\" width=\"100\">");
						printf("<input type=\"button\" value=\"继续下一步\" onclick=\"javascript:window.location='mediaSet.cgi'\">");
                }
                else{
                       printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">kunlun_resolution: %s</DIV>\n",kunlun_resolution);
                       printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">kunlun_bitRate: %s</DIV>\n",kunlun_bitRate);
                       printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">kunlun_videoCoding: %s</DIV>\n",kunlun_videoCoding);
                       printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">kunlun_audio_bitRate: %s</DIV>\n",kunlun_audio_bitRate);
                       printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">kunlun_audioCoding: %s</DIV>\n",kunlun_audioCoding);
					   
					   // int InitFile_ChangeConfigVal(char *dstkey ,char *value,int valuelen)
					   // 尚未确定，暂时屏蔽之。
					   /*
					   nRet = InitFile_ChangeConfigVal("sip.local.ip", kunlun_resolution, strlen(kunlun_resolution));
					   nRet = InitFile_ChangeConfigVal("sip.local.mask", kunlun_bitRate, strlen(kunlun_bitRate));
					   nRet = InitFile_ChangeConfigVal("sip.local.ip", kunlun_videoCoding, strlen(kunlun_videoCoding));
					   nRet = InitFile_ChangeConfigVal("sip.local.mask", kunlun_audio_bitRate, strlen(kunlun_audio_bitRate));
					   nRet = InitFile_ChangeConfigVal("sip.local.gateway", kunlun_gateway, strlen(kunlun_audioCoding));
					   
					   // int InitFile_SaveConfig()
					   nRet = InitFile_SaveConfig();


					   
					   printf("<DIV STYLE=\"COLOR:RED\">操作成功，即将自动刷新页面.</DIV>\n");
					   printf("<SCRIPT LANGUAGE=\"JavaScript\">window.location.href=\"mediaSet.cgi\";</script>");					   
					   */
					   // 测试时手动跳转，实现后需自动跳转。
					   printf("<HR COLOR=\"blue\" align=\"left\" width=\"100\">");
					   printf("<input type=\"button\" value=\"继续下一步\" onclick=\"javascript:window.location='mediaSet.cgi'\">");
                }	
        }
		
        printf("</div>\n");
        printf("</BODY>\n");
        printf("</HTML>\n");
        fflush(stdout);
        return 0;
}
