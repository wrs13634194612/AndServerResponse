
#include <stdio.h>
#include "initFileConfig.h"
#include "kunlun-string.h"

char htmls[][256] = {
"<!DOCTYPE html>\n",
"<html lang=\"cn\">\n",
"<head>\n",
"    <meta charset=\"UTF-8\">\n",
"    <title>流媒体配置</title>\n",
"    <meta name=\"renderer\" content=\"webkit\">\n",
"    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">\n",
"    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\">\n",
"    <meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black\">\n",
"    <meta name=\"apple-mobile-web-app-capable\" content=\"yes\">\n",
"    <meta name=\"format-detection\" content=\"telephone=no\">\n",
"    <link rel=\"icon\" href=\"/image/favicon.ico\" type=\"image/x-icon\">\n",
"    <link rel=\"stylesheet\" href=\"/css/resets.css\">\n",
"    <link rel=\"stylesheet\" href=\"/css/inter.css\">\n",
"    <script type=\"text/javascript\" src=\"/src/jquery-1.8.0.min.js\"></script>\n",
"    <script>\n",
"        $(function(){\n",
"            // 下拉菜单点击监听事件\n",
"            var menu = $('.setforms .ovalue');\n",
"            menu.each(function (item,index) {\n",
"                menu.eq(item).click(function () {\n",
"                    $('.menudown').hide();\n",
"                    $(this).next().show();\n",
"                });\n",
"            });\n",
"            // 点击子菜单监听事件\n",
"            $('.menudown li').click(function () {\n",
"                var txt = $(this).text();\n",
"                $(this).addClass('curItem').siblings().removeClass('curItem');\n",
"                $(this).parent().prev().html(txt+'<i></i>');\n",
"                $(this).parent().hide();\n",
"            });\n",
"            // 点击页面空白处隐藏下拉菜单\n",
"            $('body').bind('click',function (ev) {\n",
"                //console.log($(ev.target))\n",
"                if($(ev.target).parents('.slider').length == 0){\n",
"                    $('.menudown').hide();\n",
"                }\n",
"            });\n",
"\n",
"            // 复选框按钮点击事件监听\n",
"            $('.super span').click(function(){\n",
"                $(this).toggleClass('checked');\n",
"                var name = this.className;\n",
"                return checks(name);\n",
"            });\n",
"            function checks(type) {\n",
"                if (type == 'checked') {\n",
"                    $(':input[type=\"text\"]').attr('readonly', 'readonly');\n",
"                } else {\n",
"                    $(':input[type=\"text\"]').removeAttr('readonly');\n",
"                }\n",
"            }\n",
"        });\n",
"    </script>\n",
"</head>\n",
"\n",
"<body>\n",
"    <div class=\"inter-containter\">\n",
"		 <form class=\"setforms\" action=\"/cgi-bin/mediaSet-save.cgi\" method=\"post\">\n",
"            <div class=\"inputs\" style=\"padding-left: 150px;margin-bottom: 25px;\">\n",
"                <h3 class=\"media\">视频</h3>\n",
"                <div class=\"media-group\">\n",
"                    <label for=\"\">分辨率：</label>\n",
"                    <div class=\"slider\">\n",
"                        <p class=\"ovalue\">%s<i></i></p>\n",
"                        <ul class=\"menudown\">\n",
"                            <li class=\"curItem\">1080P</li>\n",
"                            <li>720P</li>\n",
"                            <li>D1</li>\n",
"                        </ul>\n",
"                    </div>\n",
"                </div>\n",
"                <div class=\"media-group\">\n",
"                    <label for=\"\">码率：</label>\n",
"                    <div class=\"slider\">\n",
"                        <p class=\"ovalue\">%s<i></i></p>\n",
"                        <ul class=\"menudown\">\n",
"                            <li class=\"curItem\">4M</li>\n",
"                            <li>2M</li>\n",
"                            <li>1M</li>\n",
"                        </ul>\n",
"                    </div>\n",
"                </div>\n",
"                <div class=\"media-group\">\n",
"                    <label for=\"\">编码：</label>\n",
"                    <div class=\"slider\">\n",
"                        <p class=\"ovalue\">%s<i></i></p>\n",
"                        <ul class=\"menudown\">\n",
"                            <li class=\"curItem\">H265</li>\n",
"                            <li>H264</li>\n",
"                        </ul>\n",
"                    </div>\n",
"                </div>\n",
"            </div>\n",
"            <div class=\"inputs\" style=\"padding-left: 150px;margin-bottom: 25px;\">\n",
"                <h3 class=\"media\">音频</h3>\n",
"                <div class=\"media-group\">\n",
"                    <label for=\"\">音频采集：</label>\n",
"                    <div class=\"slider\">\n",
"                        <p class=\"ovalue\">%s<i></i></p>\n",
"                        <ul class=\"menudown\">\n",
"                            <li class=\"curItem\">8K</li>\n",
"                            <li>16K</li>\n",
"                            <li>32K</li>\n",
"                        </ul>\n",
"                    </div>\n",
"                </div>\n",
"                <div class=\"media-group\">\n",
"                    <label for=\"\">编码：</label>\n",
"                    <div class=\"slider\">\n",
"                        <p class=\"ovalue\">%s<i></i></p>\n",
"                        <ul class=\"menudown\">\n",
"                            <li class=\"curItem\">G711.a</li>\n",
"                            <li>G712.b</li>\n",
"                        </ul>\n",
"                    </div>\n",
"                </div>\n",
"            </div>\n",
"            <div class=\"super\">能使水印叠加<span class=\"checked\"></span></div>\n",
"            <div class=\"btns\">\n",
"                <button class=\"save\" type=\"button\">保存</button>\n",
"                <button class=\"cancel\" type=\"reset\">取消</button>\n",
"            </div>\n",
"        </form>\n",
"    </div>\n",
"</body>\n",
"</html>"
};

#define GET_ARRAY_LEN(array,len){len = (sizeof(array) / sizeof(array[0]));}

int main()
{
	printf("Content-type:text/html\n\n"); //这句一定要加上

	// add other html elements.
	int nRet = InitFile_Load("/opt/app/");
	//printf("InitFile_Load(/opt/app/) return %d.\n", nRet);

	char* kunlun_resolution_ini_ptr = "1080P";//InitFile_FindConfigKey("sip.local.ip");
	char* kunlun_bitRate_ini_ptr = "4M";//InitFile_FindConfigKey("sip.local.mask");
	char* kunlun_videoCoding_ini_ptr = "H265";//InitFile_FindConfigKey("sip.local.gateway");
	char* kunlun_audio_bitRate_ini_ptr = "8K";//InitFile_FindConfigKey("sip.local.ip");
	char* kunlun_audioCoding_ini_ptr = "G711.a";//InitFile_FindConfigKey("sip.local.mask");

	char* kunlun_resolution_ptr = rtrim(kunlun_resolution_ini_ptr);
	char* kunlun_bitRate_ptr = rtrim(kunlun_bitRate_ini_ptr);
	char* kunlun_videoCoding_ptr = rtrim(kunlun_videoCoding_ini_ptr);
	char* kunlun_audio_bitRate_ptr = rtrim(kunlun_audio_bitRate_ini_ptr);
	char* kunlun_audioCoding_ptr = rtrim(kunlun_audioCoding_ini_ptr);

	int arr_len;
	GET_ARRAY_LEN(htmls,arr_len)
	//printf("GET_ARRAY_LEN is：%d.\n", arr_len);	// 47
	
	int i;
	for (i = 0; i < arr_len; i++)
	{
		if (72-7 == i)
		{	// resolution
			printf(htmls[i], kunlun_resolution_ptr);
		}
		else if (83-7 == i)
		{	// bitRate
			printf(htmls[i], kunlun_bitRate_ptr);
		}
		else if (94-7 == i)
		{	// videoCoding
			printf(htmls[i], kunlun_videoCoding_ptr);
		}
		else if (107-7 == i)
		{	// audio_bitRate
			printf(htmls[i], kunlun_audio_bitRate_ptr);
		}
		else if (118-7 == i)
		{	// audioCoding
			printf(htmls[i], kunlun_audioCoding_ptr);
		}
		else
		{
			printf(htmls[i]);
		}
	}

	return 0;
}
