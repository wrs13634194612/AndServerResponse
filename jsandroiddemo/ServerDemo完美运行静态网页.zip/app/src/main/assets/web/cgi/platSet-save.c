﻿#include <stdio.h>
#include <stdlib.h>
 #include <string.h>

#include "initFileConfig.h"

int main(void){
        int len, nRet;
        char *lenstr,poststr[256];
		char kunlun_deviceid[256],kunlun_port[256],kunlun_username[256],kunlun_reaml[256],kunlun_password[256];
        //char m[10],n[10];
		
		// add other html elements.
		nRet = InitFile_Load("/opt/app/");
		//printf("InitFile_Load(/opt/app/) return %d.\n", nRet);
		
        printf("Content-Type:text/html\n\n");
        printf("<HTML>\n");
        printf("<HEAD>\n<meta charset=\"UTF-8\">\n<TITLE >saveConfig</TITLE>\n</HEAD>\n");
        printf("<BODY>\n");
        printf("<div style=\"font-size:12px\">\n");
        lenstr = getenv("CONTENT_LENGTH");
        if(lenstr == NULL)
		{
                printf("<DIV STYLE=\"COLOR:RED\">Error parameters should be entered!</DIV>\n");
				printf("<HR COLOR=\"blue\" align=\"left\" width=\"100\">");
				printf("<input type=\"button\" value=\"继续下一步\" onclick=\"javascript:window.location='platSet.cgi'\">");
		}
        else{
				///*
                len=atoi(lenstr);
                fgets(poststr,len+1,stdin);
                if(sscanf(poststr,"deviceid=%[^&]&port=%[^&]&username=%[^&]&reaml=%[^&]&password=%s",\
					kunlun_deviceid,kunlun_port,kunlun_username,kunlun_reaml,kunlun_password)!=5){
                        printf("<DIV STYLE=\"COLOR:RED\">Error: Parameters are not right! poststr: %s</DIV>\n", poststr);
						printf("<HR COLOR=\"blue\" align=\"left\" width=\"100\">");
						printf("<input type=\"button\" value=\"继续下一步\" onclick=\"javascript:window.location='platSet.cgi'\">");
                }
                else{
                       printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">kunlun_deviceid: %s</DIV>\n",kunlun_deviceid);
                       printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">kunlun_mask: %s</DIV>\n",kunlun_port);
                       printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">kunlun_username: %s</DIV>\n",kunlun_username);
                       printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">kunlun_reaml: %s</DIV>\n",kunlun_reaml);
                       printf("<DIV STYLE=\"COLOR:GREEN; font-size:15px;font-weight:bold\">kunlun_password: %s</DIV>\n",kunlun_password);
					   // int InitFile_ChangeConfigVal(char *dstkey ,char *value,int valuelen)
					   nRet = InitFile_ChangeConfigVal("sip.local.deviceid", kunlun_deviceid, strlen(kunlun_deviceid));
					   nRet = InitFile_ChangeConfigVal("sip.local.port", kunlun_port, strlen(kunlun_port));
					   nRet = InitFile_ChangeConfigVal("sip.local.username", kunlun_username, strlen(kunlun_username));
					   nRet = InitFile_ChangeConfigVal("sip.local.reaml", kunlun_reaml, strlen(kunlun_reaml));
					   nRet = InitFile_ChangeConfigVal("sip.local.passwd", kunlun_password, strlen(kunlun_password));
					   // int InitFile_SaveConfig()
					   nRet = InitFile_SaveConfig();
					   
					   printf("<DIV STYLE=\"COLOR:RED\">操作成功，即将自动刷新页面.</DIV>\n");
					   printf("<SCRIPT LANGUAGE=\"JavaScript\">window.location.href=\"platSet.cgi\";</script>");					   
                }	
        }
		
        printf("</div>\n");
        printf("</BODY>\n");
        printf("</HTML>\n");
        fflush(stdout);
        return 0;
}
