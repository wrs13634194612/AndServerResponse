
#include <stdio.h>
#include "initFileConfig.h"
#include "kunlun-string.h"

char htmls[][256] = {
"<!DOCTYPE html>\n",
"<html lang=\"cn\">\n",
"<head>\n",
"    <meta charset=\"UTF-8\">\n",
"    <title>平台接入配置</title>\n",
"    <meta name=\"renderer\" content=\"webkit\">\n",
"    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">\n",
"    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\">\n",
"    <meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black\">\n",
"    <meta name=\"apple-mobile-web-app-capable\" content=\"yes\">\n",
"    <meta name=\"format-detection\" content=\"telephone=no\">\n",
"    <link rel=\"icon\" href=\"/image/favicon.ico\" type=\"image/x-icon\">\n",
"    <link rel=\"stylesheet\" href=\"/css/resets.css\">\n",
"    <link rel=\"stylesheet\" href=\"/css/inter.css\">\n",
"</head>\n",
"\n",
"<body>\n",
"    <div class=\"inter-containter\">\n",
"		<form class=\"setforms\" action=\"/cgi-bin/platSet-save.cgi\" method=\"post\">\n",
"            <div class=\"inputs\" style=\"border: none;\">\n",
"                <div class=\"set-group\">\n",
"                    <label for=\"\">国标ID：</label>\n",
"                    <input type=\"text\" name=\"deviceid\" value=\"%s\">\n",
"                </div>\n",
"                <div class=\"set-group\">\n",
"                    <label for=\"\">端口：</label>\n",
"                    <input type=\"text\" name=\"port\" value=\"%s\">\n",
"                </div>\n",
"                <div class=\"set-group\">\n",
"                    <label for=\"\">名字：</label>\n",
"                    <input type=\"text\" name=\"username\" value=\"%s\">\n",
"                </div>\n",
"                <div class=\"set-group\">\n",
"                    <label for=\"\">realm：</label>\n",
"                    <input type=\"text\" name=\"reaml\" value=\"%s\">\n",
"                </div>\n",
"                <div class=\"set-group\">\n",
"                    <label for=\"\">密码：</label>\n",
"                    <input type=\"text\" name=\"password\" value=\"%s\">\n",
"                </div>\n",
"            </div>\n",
"            <div class=\"btns\">\n",
"                <button class=\"save\" type=\"submit\">保存</button>\n",
"                <button class=\"cancel\" type=\"reset\">取消</button>\n",
"            </div>\n",
"        </form>\n",
"    </div>\n",
"</body>\n",
"</html>"
};

#define GET_ARRAY_LEN(array,len){len = (sizeof(array) / sizeof(array[0]));}

int main()
{
	printf("Content-type:text/html\n\n"); //这句一定要加上

	// add other html elements.
	int nRet = InitFile_Load("/opt/app/");
	//printf("InitFile_Load(/opt/app/) return %d.\n", nRet);

	char* kunlun_deviceid_ini_ptr = InitFile_FindConfigKey("sip.local.deviceid");
	char* kunlun_port_ini_ptr = InitFile_FindConfigKey("sip.local.port");
	char* kunlun_username_ini_ptr = InitFile_FindConfigKey("sip.local.username");
	char* kunlun_reaml_ini_ptr = InitFile_FindConfigKey("sip.local.reaml");
	char* kunlun_password_ini_ptr = InitFile_FindConfigKey("sip.local.passwd");
	
	char* kunlun_deviceid_ptr = rtrim(kunlun_deviceid_ini_ptr);
	char* kunlun_port_ptr = rtrim(kunlun_port_ini_ptr);
	char* kunlun_username_ptr = rtrim(kunlun_username_ini_ptr);
	char* kunlun_reaml_ptr = rtrim(kunlun_reaml_ini_ptr);
	char* kunlun_password_ptr = rtrim(kunlun_password_ini_ptr);


	int arr_len;
	GET_ARRAY_LEN(htmls,arr_len)
	//printf("GET_ARRAY_LEN is：%d.\n", arr_len);	// 47
	
	int i;
	for (i = 0; i < arr_len; i++)
	{
		if (22 == i)
		{	// deviceid
			printf(htmls[i], kunlun_deviceid_ptr);
		}
		else if (26 == i)
		{	// port
			printf(htmls[i], kunlun_port_ptr);
		}
		else if (30 == i)
		{	// username
			printf(htmls[i], kunlun_username_ptr);
		}
		else if (34 == i)
		{	// reaml
			printf(htmls[i], kunlun_reaml_ptr);
		}
		else if (38 == i)
		{	// password
			printf(htmls[i], kunlun_password_ptr);
		}
		else
		{
			printf(htmls[i]);
		}
	}

	return 0;
}
