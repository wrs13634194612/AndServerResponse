$(function() {
	// 用户名校验
	var usernameflag = true;
	var passwordflag = true;

	$("#username").blur(function() {
		var userValue = $("#username").val();
		var reg = /^[a-zA-Z0-9_-]{4,12}$/;
		if(!reg.test(userValue)) {
			$(this).data('s', 0);
			$(this).next().html('用户名有误，且字符长度必须是4-12位！');
			usernameflag = false
		} else {
			$(this).data('s', 1);
			$(this).next().html('');
			usernameflag = true
		}
	});
	// 密码校验
	$("#password").blur(function() {
		var pswValue = $("#password").val();
		var reg = /^[^\u4e00-\u9fa5]{4,}$/;
		if(!reg.test(pswValue)) {
			$(this).data('s', 0);
			$(this).next().html('密码有误，且字符长度必须是4位以上！');
			passwordflag = false
		} else {
			$(this).data('s', 1);
			$(this).next().html('');
			passwordflag = true
		}
	});
	// 记住密码点击事件监听
	var flag = false;
	var username = '';
	var passwd = '';

	//获取初始化本地
	for(var i = localStorage.length - 1; i >= 0; i--) {
		if(localStorage.key(i) == "username") {
			username = localStorage.getItem(localStorage.key(i));
			passwd = localStorage.getItem("passwd");
			$("#username").val(username);
			$("#password").val(passwd);
			flag = true;
			$('.remember').addClass('checkedRemember');
		}
	}

	$('.remember').click(function() {
		if(!flag) {
			$(this).addClass('checkedRemember');
			flag = true;
		} else {
			$(this).removeClass('checkedRemember');
			flag = false;
		}
	});

	$('#username').live('input propertychange', function() {
		username = localStorage.getItem('username');
		passwd = localStorage.getItem('passwd');
		if($('#username').val() == username) {
			$("#username").val(username);
			$("#password").val(passwd);
			flag = true;
			$('.remember').addClass('checkedRemember');
		} else {
			$("#password").val('');
			flag = false;
			$('.remember').removeClass('checkedRemember');
		}
	})

	//回车事件
	$(document).ready(function() {
		$('body').keydown(function(e) {
			if(e.keyCode == 13) {
				login();
			}
		});
	});

	$('.submit').click(function() {
		login();
	});

	function login() {
		var username = $("#username").val();
		var password = $("#password").val();
		var passwd = $.md5(password);

		var date = new Date().format('yyyy-MM-dd hh:mm:ss');
		var sign = 'passwd' + passwd + 'timestamp' + date + 'user' + username;
		sign = $.md5(sign).toUpperCase();

		if(flag) {
			localStorage.setItem("username", username);
			localStorage.setItem("passwd", password);
		} else {
			window.localStorage.clear();
		}
		if(passwordflag == true && usernameflag == true) {
			$.ajax({
				url: "/user/logincheck",
				type: "get", // 提交方式
				data: {
					"user": username,
					"passwd": passwd,
					"timestamp": date,
					"sign": sign
				},
				dataType: "json",
				success: function(res) {
					if(res.code == "200") {
						window.location.href = 'views/main.html';
					} else {
						$("#password").next().html('密码有误，请重新输入！');
					}
				}
			});
		}
	}
})