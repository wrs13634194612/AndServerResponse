package com.example.serverdemo.controller;

import android.util.Log;

import com.yanzhenjie.andserver.annotation.Controller;
import com.yanzhenjie.andserver.annotation.GetMapping;


@Controller
public class PageController {

    //第一个页面 并且这个类里面的内容  尽量别动
    @GetMapping(path = "/")
    public String index(){
        return "forward:/index.html";
    }




}
