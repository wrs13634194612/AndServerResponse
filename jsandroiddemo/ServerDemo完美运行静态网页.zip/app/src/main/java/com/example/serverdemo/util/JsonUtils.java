package com.example.serverdemo.util;


import com.alibaba.fastjson.JSON;
import com.example.serverdemo.model.ReturnData;

import java.lang.reflect.Type;

/**
 * Created by Zhenjie Yan on 2018/6/9.
 */
public class JsonUtils {

    /**
     * Business is successful.
     *
     * @param data return data.
     * @return json.
     */
    public static String successfulJson(String data) {
        ReturnData returnData = new ReturnData();
        returnData.setCode(data);
        returnData.setMessage("成功");
        return JSON.toJSONString(returnData);
    }

    /**
     * Business is failed.
     *
     * @param code    error code.
     * @param message message.
     * @return json.
     */
    public static String failedJson(int code, String message) {
        ReturnData returnData = new ReturnData();
        returnData.setCode(message);
        returnData.setMessage("失败");
        return JSON.toJSONString(returnData);
    }

    /**
     * Converter object to json string.
     *
     * @param data the object.
     * @return json string.
     */
    public static String toJsonString(Object data) {
        return JSON.toJSONString(data);
    }

    /**
     * Parse json to object.
     *
     * @param json json string.
     * @param type the type of object.
     * @param <T>  type.
     * @return object.
     */
    public static <T> T parseJson(String json, Type type) {
        return JSON.parseObject(json, type);
    }
}